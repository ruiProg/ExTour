package com.andrei.template;

public class Constants {
  private Constants() {
  }

  public static final String WHAT_EVER = "https://wtfismyip.com";
}

# Android ActionBar Tab Example
This android action bar tab example shows you how to add tabs in your android app actionbar. Click the below link for tutorial.

http://www.viralandroid.com/2015/09/android-actionbar-tabs-example.html

<h1>Screenshot:</h1>

![Alt text](https://raw.githubusercontent.com/pacificregmi/ActionBarTabExample/master/actionbar-tab-example-screenshot.png "Optional title")
